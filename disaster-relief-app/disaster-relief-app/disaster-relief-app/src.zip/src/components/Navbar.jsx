import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Home, Upload, User, FileText, Mail, Droplet } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-secondary-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <Link to="/" className="text-xl font-bold text-primary-600 flex items-center gap-2">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <Droplet size={16} className="text-white" aria-hidden="true" />
            </div>
            <span>FloodGuard AI</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-secondary-600 hover:text-primary-600 flex items-center gap-2">
              <Home size={16} />
              Home
            </Link>
            <Link to="/upload" className="text-secondary-600 hover:text-primary-600 flex items-center gap-2">
              <Upload size={16} />
              Analyze
            </Link>
            <Link to="/history" className="text-secondary-600 hover:text-primary-600 flex items-center gap-2">
              <FileText size={16} />
              Reports
            </Link>
            <Link to="/contact" className="text-secondary-600 hover:text-primary-600 flex items-center gap-2">
              <Mail size={16} />
              Contact
            </Link>
            <Link to="/profile" className="text-secondary-600 hover:text-primary-600 flex items-center gap-2">
              <User size={16} />
              Profile
            </Link>
            <Link to="/auth">
                <button className="bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700 transition flex items-center gap-2">
                    <User size={16} />
                    Login
                </button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-secondary-500">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-secondary-100 p-4 space-y-4 shadow-lg">
          <Link to="/" className="block text-secondary-600 font-medium flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <Home size={16} />
            Home
          </Link>
          <Link to="/upload" className="block text-secondary-600 font-medium flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <Upload size={16} />
            Analyze Image
          </Link>
          <Link to="/history" className="block text-secondary-600 font-medium flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <FileText size={16} />
            Your Reports
          </Link>
          <Link to="/contact" className="block text-secondary-600 font-medium flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <Mail size={16} />
            Contact
          </Link>
          <Link to="/profile" className="block text-secondary-600 font-medium flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <User size={16} />
            Profile
          </Link>
          <Link to="/auth" className="block text-primary-600 font-bold flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <User size={16} />
            Login / Register
          </Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;