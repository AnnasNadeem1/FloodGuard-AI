import React from 'react';

export const Card = ({ children, className = "" }) => {
  return (
    <div className={`bg-white rounded-2xl shadow-sm border border-secondary-100 p-6 ${className}`}>
      {children}
    </div>
  );
};