import React from 'react';
import { Link } from 'react-router-dom';
import { User, Mail, MapPin, Calendar, Edit2 } from 'lucide-react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';

const Profile = () => {
  
  // Local images stored in public/assets
  const localImages = [
    "/assets/downtown.jpeg",
    "/assets/riverside.jpeg",
    "/assets/north.jpeg"
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Profile Header */}
      <Card className="mb-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-primary-600 to-primary-400"></div>
        <div className="relative pt-16 px-6 pb-6 flex flex-col sm:flex-row items-center sm:items-end gap-6">
          <div className="w-32 h-32 rounded-full border-4 border-white bg-white shadow-lg flex items-center justify-center text-secondary-300">
            <User size={64} />
          </div>
          <div className="flex-1 text-center sm:text-left mb-2">
            <h1 className="text-2xl font-bold text-secondary-900">Alex Johnson</h1>
            <p className="text-secondary-500">Disaster Response Coordinator</p>
          </div>
          <Button variant="secondary" className="mb-2">
            <Edit2 size={16} /> Edit Profile
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Col: Info */}
        <div className="space-y-6">
          <Card>
            <h3 className="font-bold text-secondary-900 mb-4">About</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-secondary-600">
                <Mail size={18} />
                <span className="text-sm">alex.johnson@example.com</span>
              </div>
              <div className="flex items-center gap-3 text-secondary-600">
                <MapPin size={18} />
                <span className="text-sm">New York, USA</span>
              </div>
              <div className="flex items-center gap-3 text-secondary-600">
                <Calendar size={18} />
                <span className="text-sm">Joined Jan 2024</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="font-bold text-secondary-900 mb-4">Statistics</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-primary-50 p-3 rounded-xl text-center">
                <h4 className="text-2xl font-bold text-primary-600">24</h4>
                <p className="text-xs text-primary-700">Reports</p>
              </div>
              <div className="bg-success-50 p-3 rounded-xl text-center">
                <h4 className="text-2xl font-bold text-success-600">12</h4>
                <p className="text-xs text-success-700">Verified</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Col: Recent Activity */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-secondary-900">Recent Submissions</h2>
            <Link to="/history" className="text-primary-600 text-sm font-medium hover:underline">
              View All
            </Link>
          </div>

          {[0, 1, 2].map((index) => (
            <Card 
              key={index} 
              className="flex flex-col sm:flex-row gap-4 p-4 hover:bg-secondary-50 transition cursor-pointer group"
            >
              <div className="w-full sm:w-32 h-32 sm:h-24 bg-secondary-200 rounded-lg overflow-hidden">
                <img 
                  src={localImages[index]}
                  className="w-full h-full object-cover group-hover:scale-105 transition"
                  alt="Disaster"
                />
              </div>

              <div className="flex-1 py-1">
                <div className="flex justify-between items-start">
                  <h4 className="font-bold text-secondary-900">
                    Flood Assessment #{index + 1}04
                  </h4>
                  <Badge severity="Severe" />
                </div>

                <p className="text-sm text-secondary-500 mt-1">
                  Submitted on Jan 15, 2024 • 2:30 PM
                </p>

                <p className="text-sm text-secondary-600 mt-2 line-clamp-1">
                  Structural damage observed near the river bank. Requires immediate...
                </p>
              </div>
            </Card>
          ))}

        </div>

      </div>
    </div>
  );
};

export default Profile;
