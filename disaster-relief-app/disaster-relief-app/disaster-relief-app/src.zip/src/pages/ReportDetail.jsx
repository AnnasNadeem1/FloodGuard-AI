import { useParams, Link } from "react-router-dom";

// Small improvement: add a back link to the reports listing

const ReportDetails = () => {
  const { id } = useParams();

  // Use the same mock data as the History page so the detail view shows the correct image
  const reports = [
    { id: 1, title: "Downtown Sector 4 Flood", date: "Jan 15, 2024", severity: "Severe", img: "/assets/downtown.jpeg", location: "Downtown" },
    { id: 2, title: "Riverside Residential Area", date: "Jan 14, 2024", severity: "Moderate", img: "/assets/riverside.jpeg", location: "Riverside" },
    { id: 3, title: "North Bridge Inspection", date: "Jan 12, 2024", severity: "Minor", img: "/assets/north.jpeg", location: "North District" },
    { id: 4, title: "East Coast Highway", date: "Jan 10, 2024", severity: "Severe", img: "/assets/highway.jpeg", location: "East Coast Highway" },
  ];

  const report = reports.find((r) => String(r.id) === String(id));
  const imgSrc = report?.img || "https://via.placeholder.com/800x400";

  return (
    <div className="bg-[#F9FBFF] min-h-screen text-gray-800">

      {/* HEADER */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="mb-4">
          <Link to="/history" className="text-sm text-primary-600 hover:underline">← Back to Reports</Link>
        </div>
        <h1 className="text-3xl font-bold mb-2">
          Flood Assessment #{id}
        </h1>
        <p className="text-gray-600">
          Submitted on Jan 15, 2024 • 2:30 PM
        </p>
      </section>

      {/* MAIN CONTENT */}
      <section className="max-w-6xl mx-auto px-6 pb-24 grid lg:grid-cols-3 gap-10">

        {/* LEFT: IMAGE + SUMMARY */}
        <div className="lg:col-span-2 space-y-8">

          {/* IMAGE */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <img
              src={imgSrc}
              alt={report ? report.title : "Flood Scene"}
              className="rounded-xl w-full object-cover"
            />
          </div>

          {/* DAMAGE SUMMARY */}
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h3 className="text-xl font-bold mb-4">Damage Summary</h3>
            <p className="text-gray-600 leading-relaxed">
              {report ? (
                <>
                  Structural damage observed near {report.location} with water levels
                  exceeding safe thresholds. Multiple residential units affected.
                  Immediate evacuation and reinforcement measures recommended.
                </>
              ) : (
                <>Structural damage observed near the river bank with water levels exceeding safe thresholds. Multiple residential units affected. Immediate evacuation and reinforcement measures recommended.</>
              )}
            </p>
          </div>

          {/* AI ANALYSIS */}
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h3 className="text-xl font-bold mb-6">AI Analysis Results</h3>

            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-gray-500">Flood Severity</p>
                <span className="inline-block mt-1 px-4 py-1 text-sm font-semibold text-red-600 bg-red-100 rounded-full">
                  Severe
                </span>
              </div>

              <div>
                <p className="text-sm text-gray-500">Confidence Level</p>
                <p className="font-semibold">92%</p>
              </div>

              <div>
                <p className="text-sm text-gray-500">Estimated Damage Area</p>
                <p className="font-semibold">3.4 km²</p>
              </div>

              <div>
                <p className="text-sm text-gray-500">Infrastructure Risk</p>
                <p className="font-semibold">High</p>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: ACTIONS + METADATA */}
        <div className="space-y-8">

          {/* STATUS CARD */}
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h4 className="font-bold mb-4">Report Status</h4>

            <div className="flex items-center justify-between">
              <span className="text-gray-600">Current Severity</span>
              <span className="px-3 py-1 text-sm font-semibold text-red-600 bg-red-100 rounded-full">
                Severe
              </span>
            </div>
          </div>

          {/* RECOMMENDED ACTIONS */}
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h4 className="font-bold mb-4">Recommended Actions</h4>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Initiate emergency evacuation protocols</li>
              <li>Deploy flood barriers near river banks</li>
              <li>Alert local disaster response teams</li>
              <li>Monitor water levels continuously</li>
            </ul>
          </div>

          {/* DOWNLOAD */}
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h4 className="font-bold mb-4">Export Report</h4>
            <button className="w-full bg-blue-600 text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition">
              Download PDF Report
            </button>
          </div>

        </div>

      </section>

    </div>
  );
};

export default ReportDetails;
