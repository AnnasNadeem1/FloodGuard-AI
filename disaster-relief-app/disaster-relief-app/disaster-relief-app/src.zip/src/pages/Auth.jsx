import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate('/profile'); 
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 animate-fade-in-up shadow-xl">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-secondary-900">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="text-secondary-500 text-sm mt-2">
            {isLogin 
              ? 'Enter your credentials to access your account' 
              : 'Join FloodGuard to start analyzing disaster data'}
          </p>
        </div>

        <div className="flex p-1 bg-secondary-50 rounded-xl mb-8 border border-secondary-100">
          <button
            onClick={() => setIsLogin(true)}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              isLogin ? 'bg-white text-primary-600 shadow-sm' : 'text-secondary-500 hover:text-secondary-700'
            }`}
          >
            Login
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              !isLogin ? 'bg-white text-primary-600 shadow-sm' : 'text-secondary-500 hover:text-secondary-700'
            }`}
          >
            Register
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <Input label="Full Name" placeholder="e.g. Alex Johnson" icon={User} />
          )}
          
          <Input label="Email Address" type="email" placeholder="name@company.com" icon={Mail} />
          <Input label="Password" type="password" placeholder="••••••••" icon={Lock} />

          {isLogin && (
            <div className="flex justify-end">
              <Link to="#" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
                Forgot Password?
              </Link>
            </div>
          )}

          <Button className="w-full mt-6">
            {isLogin ? 'Sign In' : 'Create Account'}
            <ArrowRight size={18} />
          </Button>
        </form>
      </Card>
    </div>
  );
};

export default Auth;