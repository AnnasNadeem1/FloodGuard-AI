import React, { useState } from 'react';
import { UploadCloud, File, X, Loader2 } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';

const UploadPortal = () => {
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const handleDrop = (e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) setFile(droppedFile);
  };

  const handleAnalyze = () => {
    if (!file) return;
    setAnalyzing(true);
    // Simulate AI API call
    setTimeout(() => {
      setAnalyzing(false);
      setResult({
        severity: "Severe",
        summary: "Structural collapse detected in residential area. High flood waters observed near foundation.",
        confidence: "94%"
      });
    }, 2500);
  };

  return (
    <div className="max-w-2xl mx-auto py-10 px-4">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-secondary-900">Analyze Disaster Image</h1>
        <p className="text-secondary-500 mt-2">Upload an image to detect flood severity and damage.</p>
      </div>

      <Card className="mb-6">
        {!file ? (
          <div 
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="border-2 border-dashed border-primary-200 rounded-xl p-10 flex flex-col items-center justify-center bg-primary-50/50 hover:bg-primary-50 transition-colors cursor-pointer"
          >
            <div className="bg-primary-100 p-4 rounded-full mb-4">
              <UploadCloud className="text-primary-600 w-8 h-8" />
            </div>
            <p className="text-secondary-600 font-medium">Drag and drop an image here</p>
            <p className="text-secondary-400 text-sm mt-1">or</p>
            <label className="mt-4">
              <span className="bg-primary-600 text-white px-4 py-2 rounded-lg cursor-pointer hover:bg-primary-700 transition">Choose File</span>
              <input type="file" className="hidden" onChange={(e) => setFile(e.target.files[0])} />
            </label>
          </div>
        ) : (
          <div className="relative">
             <img src={URL.createObjectURL(file)} alt="Preview" className="w-full h-64 object-cover rounded-xl" />
             <button 
               onClick={() => { setFile(null); setResult(null); }}
               className="absolute top-2 right-2 bg-white/90 p-2 rounded-full shadow-md text-secondary-600 hover:text-danger-500"
             >
               <X size={20} />
             </button>
             <div className="mt-4 flex items-center gap-2 text-secondary-600">
               <File size={16} />
               <span className="text-sm font-medium">{file.name}</span>
             </div>
          </div>
        )}

        <textarea 
  className="w-full mt-6 p-3 rounded-xl border border-secondary-200 focus:ring-2 focus:ring-primary-500 focus:outline-none resize-none bg-gray-100 text-gray-900"
  rows="3"
  placeholder="Add additional details (optional)..."
></textarea>


        <div className="mt-6">
          <Button 
            onClick={handleAnalyze} 
            disabled={!file || analyzing} 
            className="w-full"
          >
            {analyzing ? <><Loader2 className="animate-spin" /> Analyzing...</> : "Analyze Image"}
          </Button>
        </div>
      </Card>

      {/* Results Section */}
      {result && (
        <div className="animate-fade-in-up">
          <Card className="border-l-4 border-l-danger-500">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">Analysis Results</h3>
              <span className="bg-danger-100 text-danger-700 px-3 py-1 rounded-full text-sm font-bold border border-danger-200">
                {result.severity}
              </span>
            </div>
            <p className="text-secondary-600 leading-relaxed">{result.summary}</p>
            <div className="mt-6 flex gap-3">
              <Button variant="secondary" className="flex-1">Download Report</Button>
              <Button variant="primary" className="flex-1">Save Result</Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default UploadPortal;