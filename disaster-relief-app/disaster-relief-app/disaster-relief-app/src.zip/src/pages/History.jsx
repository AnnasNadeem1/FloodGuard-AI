import React from 'react';
import { Search, Filter, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { Input } from '../components/Input';
import { Button } from '../components/Button';

const History = () => {
  // Mock Data
  const reports = [
  { id: 1, title: "Downtown Sector 4 Flood", date: "Jan 15, 2024", severity: "Severe", img: "/assets/downtown.jpeg" },
  { id: 2, title: "Riverside Residential Area", date: "Jan 14, 2024", severity: "Moderate", img: "/assets/riverside.jpeg" },
  { id: 3, title: "North Bridge Inspection", date: "Jan 12, 2024", severity: "Minor", img: "/assets/north.jpeg" },
  { id: 4, title: "East Coast Highway", date: "Jan 10, 2024", severity: "Severe", img: "/assets/highway.jpeg" },
];


  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-secondary-900">Your Reports</h1>
          <p className="text-secondary-500 mt-1">Manage and view your past disaster analysis reports.</p>
        </div>
        <div className="flex gap-2">
            <Button variant="secondary">Export All</Button>
            <Button>+ New Upload</Button>
        </div>
      </div>

      {/* Filters Bar */}
      <Card className="mb-8 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <Input icon={Search} placeholder="Search reports..." className="w-full" />
          </div>
          <div className="flex gap-2">
            <select className="px-4 py-3 rounded-xl border border-secondary-200 bg-white text-secondary-700 focus:ring-2 focus:ring-primary-500 outline-none">
                <option>All Severities</option>
                <option>Severe</option>
                <option>Moderate</option>
                <option>Minor</option>
            </select>
            <Button variant="secondary" className="px-4">
                <Filter size={18} />
            </Button>
          </div>
        </div>
      </Card>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reports.map((report) => (
          <Card key={report.id} className="p-0 overflow-hidden group cursor-pointer hover:shadow-md transition-all">
            <div className="relative h-48 overflow-hidden">
              <img src={report.img} alt={report.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
              <div className="absolute top-3 right-3">
                <Badge severity={report.severity} />
              </div>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-2 text-xs text-secondary-500 mb-2">
                <Calendar size={14} />
                {report.date}
              </div>
              <h3 className="font-bold text-secondary-900 mb-2 truncate">{report.title}</h3>
              <p className="text-sm text-secondary-500 mb-4 line-clamp-2">
                AI analysis detected {report.severity.toLowerCase()} flood levels. Immediate attention required for...
              </p>
              <Link to={`/report/${report.id}`}>
                <Button variant="secondary" className="w-full py-2 text-sm">View Full Report</Button>
              </Link>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default History;